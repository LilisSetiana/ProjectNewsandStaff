package two.example.projectnewandstaff

import two.example.projectnewandstaff.Module.GetNewsResponseItem
import two.example.projectnewandstaff.Module.GetStaffResponseItem

interface ApiService {

    @GET("news")
    suspend fun getAllNews() : List<GetNewsResponseItem>

    @GET("staf")
    suspend fun getAllStaff() : List<GetStaffResponseItem>
}