package two.example.projectnewandstaff

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import android.view.Surface
import androidx.activity.ComponentActivity
import org.w3c.dom.Text
import two.example.projectnewandstaff.Module.GetStaffResponseItem
import java.lang.reflect.Modifier

@AndroidEntryPoint
class StaffActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyRetrofitComposeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    val viewModel = viewModel(modelClass = StaffViewModel::class.java)

                    val dataStaff by viewModel.dataState.collectAsState()


                    Column(horizontalAlignment = Layout.Alignment.CenterHorizontally,
                        modifier = Modifier.padding(20.dp)) {
                        val context = LocalContext.current
                        Text(text = "Staff", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        LazyColumn {
                            items(dataStaff) {
                                StaffItem(staff = it)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StaffItem(staff: GetStaffResponseItem) {
    val context = LocalContext.current

    Column(Modifier.padding(20.dp)) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clickable {
                    context.startActivity(
                        Intent(context, DetailStaffActivity::class.java).putExtra(
                            "staff",
                            staff
                        )
                    )
                },
            backgroundColor = Color.LightGray,
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = rememberImagePainter(data = staff.image),
                    contentDescription = "img",
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(130.dp),
                    contentScale = ContentScale.Fit
                )
                Column(modifier = Modifier.padding(start = 10.dp, top = 10.dp)) {
                    Text(text = staff.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(text = staff.createdAt, fontSize = 14.sp)
                    Text(text = staff.email, fontSize = 18.sp)

                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview3() {
    MyRetrofitComposeTheme {

    }
}