package two.example.projectnewandstaff.Module

class GetStaffResponse : ArrayList<GetStaffResponseItem>()