package two.example.projectnewandstaff

import android.content.Intent
import android.graphics.Color
import android.inputmethodservice.Keyboard
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import org.w3c.dom.Text
import two.example.projectnewandstaff.Module.GetNewsResponseItem
import java.lang.reflect.Modifier

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyRetrofitComposeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    val viewModel = viewModel(modelClass = NewsViewModel::class.java)

                    val dataNews by viewModel.dataState.collectAsState()

                    Column(
                        modifier = Modifier.padding(20.dp)) {
                        val context = LocalContext.current
                        Row(modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.fillMaxWidth().weight(9f),
                                horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "News", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.height(50.dp))
                            }
                            Column(modifier = Modifier.fillMaxWidth().weight(1f),
                                horizontalAlignment = Layout.Alignment.End,
                            ) {
                                IconButton(modifier = Modifier
                                    .width(50.dp)
                                    .height(50.dp),
                                    onClick = {
                                        context.startActivity(Intent(context, StaffActivity::class.java))
                                    }) {
                                    Icon(
                                        Icons.Filled.Person,
                                        "contentDescription",
                                        tint = Color.Black)
                                }
                            }

                        }

                        LazyColumn{
                            items(dataNews){
                                NewsItem(news = it)
                            }
                        }
                    }


                }
            }
        }
    }
}

@Composable
fun NewsItem(news : GetNewsResponseItem) {

    val context = LocalContext.current

    Column() {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clickable {
                    val intent = Intent(context, DetailActivity::class.java)
                    intent.putExtra("news", news)
                    context.startActivity(intent)
                },
            backgroundColor = Color.LightGray,
            shape = RoundedCornerShape(10.dp)
        ) {
            .Row(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = rememberImagePainter(data = news.image),
                    contentDescription = "img",
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(130.dp),
                    contentScale = ContentScale.Fit
                )
                Column(modifier = Modifier.padding(start = 10.dp, top = 10.dp)) {
                    Text(text = news.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(text = news.createdAt, fontSize = 14.sp)
                    Text(text = news.author, fontSize = 18.sp)

                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
    }

}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun DefaultPreview() {
    MyRetrofitComposeTheme {
//        NewsItem()
    }
}