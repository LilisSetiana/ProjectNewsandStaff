package two.example.projectnewandstaff

import two.example.projectnewandstaff.Module.GetNewsResponseItem

@HiltViewModel
class NewsViewModel @Inject constructor(private val newsRepository: NewsRepository): ViewModel() {
    private var getNewsResponse = MutableStateFlow(emptyList<GetNewsResponseItem>())
    val dataState : StateFlow<List<GetNewsResponseItem>>
        get() = getNewsResponse

    init {
        viewModelScope.launch {
            val news = newsRepository.getAllNews()
            getNewsResponse.value = news
        }
    }
}