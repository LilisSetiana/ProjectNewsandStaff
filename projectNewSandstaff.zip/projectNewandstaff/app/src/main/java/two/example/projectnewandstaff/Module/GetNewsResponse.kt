package two.example.projectnewandstaff.Module

class GetNewsResponse : ArrayList<GetNewsResponseItem>()