package two.example.projectnewandstaff

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import android.view.Surface
import android.widget.GridLayout
import androidx.activity.ComponentActivity
import org.w3c.dom.Text
import two.example.projectnewandstaff.Module.GetStaffResponseItem
import java.lang.reflect.Modifier

class DetailStaffActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val detail = intent.getParcelableExtra<GetStaffResponseItem>("staff") as GetStaffResponseItem
        setContent {
            MyRetrofitComposeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DetailStaffScreen(staff = detail)
                }
            }
        }
    }
}

@Composable
fun DetailStaffScreen(staff: GetStaffResponseItem) {
    Column(modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(30.dp),
        horizontalAlignment = Gr.Alignment.CenterHorizontally
    ) {
        Image(
            painter = rememberImagePainter(data = staff.image),
            contentDescription = "img",
            modifier = Modifier
                .height(250.dp)
                .fillMaxWidth()
        )
        Text(text = staff.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(text = staff.createdAt, fontSize = 14.sp)
        Text(text = staff.email, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview4() {
    MyRetrofitComposeTheme {

    }
}