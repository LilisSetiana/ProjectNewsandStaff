package two.example.projectnewandstaff

import android.app.Application

@HiltAndroidApp
class BaseApplication : Application()