package two.example.projectnewandstaff

import two.example.projectnewandstaff.Module.GetStaffResponseItem

@HiltViewModel
class StaffViewModel @Inject constructor(private val newsRepository: NewsRepository): ViewModel(){

    private var getStaffResponse = MutableStateFlow(emptyList<GetStaffResponseItem>())
    val dataState: StateFlow<List<GetStaffResponseItem>>
        get() = getStaffResponse


    init {
        viewModelScope.launch {
            getStaffResponse.value = newsRepository.getAllStaff()
        }
    }
}