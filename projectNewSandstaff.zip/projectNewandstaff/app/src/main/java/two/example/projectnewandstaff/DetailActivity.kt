package two.example.projectnewandstaff

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import android.view.Surface
import androidx.activity.ComponentActivity
import org.w3c.dom.Text
import two.example.projectnewandstaff.Module.GetNewsResponseItem
import java.lang.reflect.Modifier

class DetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val detailNews =
            intent.getParcelableExtra<GetNewsResponseItem>("news") as GetNewsResponseItem
        setContent {
            MyRetrofitComposeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    DetailScreen(detailNews)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(news : GetNewsResponseItem) {
    Column(modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(30.dp),
        horizontalAlignment = Layout.Alignment.CenterHorizontally
    ) {
        Image(
            painter = rememberImagePainter(data = news.image),
            contentDescription = "img",
            modifier = Modifier
                .height(250.dp)
                .fillMaxWidth()
        )
        Text(text = news.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(text = news.createdAt, fontSize = 14.sp)
        Text(text = news.author, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(text = news.description, fontSize = 18.sp, textAlign = TextAlign.Justify)
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview2() {
    MyRetrofitComposeTheme {

    }