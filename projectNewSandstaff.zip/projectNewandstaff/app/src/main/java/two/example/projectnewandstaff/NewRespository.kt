package two.example.projectnewandstaff

import two.example.projectnewandstaff.Module.GetNewsResponseItem
import two.example.projectnewandstaff.Module.GetStaffResponseItem

class NewRepository @Inject constructor(private val apiService: ApiService) {
    suspend fun getAllNews() : List<GetNewsResponseItem> = apiService.getAllNews()
    suspend fun getAllStaff() : List<GetStaffResponseItem> = apiService.getAllStaff()
}